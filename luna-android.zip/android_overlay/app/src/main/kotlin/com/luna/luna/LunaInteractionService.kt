package com.luna.luna

import android.service.voice.VoiceInteractionService

class LunaInteractionService : VoiceInteractionService()
