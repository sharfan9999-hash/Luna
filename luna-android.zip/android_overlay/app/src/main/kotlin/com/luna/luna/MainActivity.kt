package com.luna.luna

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.Settings
import android.view.KeyEvent
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import kotlin.math.roundToInt

class MainActivity : FlutterActivity() {
    companion object { const val EXTRA_ASSIST = "luna_assist" }

    private var assistPending = false

    private fun markAssist(i: Intent?) {
        if (i?.getBooleanExtra(EXTRA_ASSIST, false) == true || i?.action == Intent.ACTION_ASSIST) {
            assistPending = true
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        markAssist(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        markAssist(intent)
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "luna/system")
            .setMethodCallHandler { call, result ->
                try {
                    val msg: Any? = when (call.method) {
                        "consumeAssistLaunch" -> { val v = assistPending; assistPending = false; v }
                        "openAssistantSettings" -> { launch(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS)); "Opened" }
                        "flashlight" -> flashlight(call.argument<Boolean>("on") ?: true)
                        "set_volume" -> setVolume(call.argument<Int>("percent") ?: 50)
                        "set_brightness" -> setBrightness(call.argument<Int>("percent") ?: 50)
                        "open_app" -> openApp(call.argument<String>("name") ?: "")
                        "set_alarm" -> setAlarm(
                            call.argument<Int>("hour") ?: 7,
                            call.argument<Int>("minute") ?: 0,
                            call.argument<String>("label") ?: "Luna alarm")
                        "set_timer" -> setTimer(
                            call.argument<Int>("seconds") ?: 60,
                            call.argument<String>("label") ?: "Luna timer")
                        "dial_number" -> {
                            launch(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(call.argument<String>("number") ?: ""))))
                            "Dialer ready, tap call"
                        }
                        "compose_sms" -> {
                            launch(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + (call.argument<String>("number") ?: "")))
                                .putExtra("sms_body", call.argument<String>("message") ?: ""))
                            "Message drafted, tap send"
                        }
                        "open_settings_panel" -> openPanel(call.argument<String>("panel") ?: "wifi")
                        "media_control" -> media(call.argument<String>("action") ?: "play_pause")
                        "open_url" -> {
                            val u = call.argument<String>("url") ?: ""
                            launch(Intent(Intent.ACTION_VIEW, Uri.parse(u)))
                            "Opened link"
                        }
                        "web_search" -> {
                            val q = call.argument<String>("query") ?: ""
                            launch(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))))
                            "Searching: $q"
                        }
                        "get_battery" -> {
                            val bm = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
                            "Battery at ${bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)} percent"
                        }
                        else -> { result.notImplemented(); return@setMethodCallHandler }
                    }
                    result.success(msg)
                } catch (e: Exception) {
                    result.error("ACTION_FAILED", e.message ?: "Action failed", null)
                }
            }
    }

    private fun launch(i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
    }

    private fun flashlight(on: Boolean): String {
        val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: throw Exception("No flashlight on this phone")
        cm.setTorchMode(id, on)
        return if (on) "Flashlight on" else "Flashlight off"
    }

    private fun setVolume(p: Int): String {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        am.setStreamVolume(AudioManager.STREAM_MUSIC, (p.coerceIn(0, 100) / 100.0 * max).roundToInt(), AudioManager.FLAG_SHOW_UI)
        return "Volume ${p.coerceIn(0, 100)}%"
    }

    private fun setBrightness(p: Int): String {
        if (!Settings.System.canWrite(this)) {
            launch(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
            return "Allow Luna to modify system settings, then ask again"
        }
        Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
        Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, (p.coerceIn(0, 100) * 255 / 100))
        return "Brightness ${p.coerceIn(0, 100)}%"
    }

    private fun openApp(name: String): String {
        val pm = packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val match = pm.queryIntentActivities(main, 0)
            .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
            .filter { it.first.contains(name, ignoreCase = true) }
            .minByOrNull { it.first.length }
            ?: throw Exception("I could not find an app called $name")
        launch(pm.getLaunchIntentForPackage(match.second)!!)
        return "Opened ${match.first}"
    }

    private fun setAlarm(h: Int, m: Int, label: String): String {
        launch(Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, h)
            .putExtra(AlarmClock.EXTRA_MINUTES, m)
            .putExtra(AlarmClock.EXTRA_MESSAGE, label)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
        return "Alarm set for %02d:%02d".format(h, m)
    }

    private fun setTimer(s: Int, label: String): String {
        launch(Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, s)
            .putExtra(AlarmClock.EXTRA_MESSAGE, label)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
        return "Timer set for $s seconds"
    }

    private fun openPanel(p: String): String {
        val action = when (p) {
            "wifi" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "display" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound" -> Settings.ACTION_SOUND_SETTINGS
            "hotspot" -> Settings.ACTION_WIRELESS_SETTINGS
            else -> if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_INTERNET_CONNECTIVITY else Settings.ACTION_WIRELESS_SETTINGS
        }
        launch(Intent(action))
        return "Opened $p settings (Android does not let apps toggle it directly)"
    }

    private fun media(a: String): String {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val code = when (a) {
            "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
            "previous" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            else -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
        }
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        return "Media: $a"
    }
}
