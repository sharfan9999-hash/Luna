import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:ota_update/ota_update.dart';
import 'package:package_info_plus/package_info_plus.dart';

class UpdateInfo {
  UpdateInfo(this.version, this.apkUrl, this.notes);
  final String version, apkUrl, notes;
}

/// Checks the latest GitHub Release of your repo (public repo needed) and
/// installs the new APK over the old one. Settings and API key are kept.
class Updater {
  Future<UpdateInfo?> check(String repo) async {
    final res = await http
        .get(Uri.parse('https://api.github.com/repos/$repo/releases/latest'),
            headers: {'Accept': 'application/vnd.github+json'})
        .timeout(const Duration(seconds: 10));
    if (res.statusCode != 200) {
      throw Exception('Could not reach releases for $repo (is the repo public?)');
    }
    final j = jsonDecode(res.body);
    final tag = (j['tag_name'] as String).replaceFirst('v', '');
    final assets = (j['assets'] as List).cast<Map<String, dynamic>>();
    final apk = assets.firstWhere((a) => (a['name'] as String).endsWith('.apk'),
        orElse: () => {});
    if (apk.isEmpty) return null;
    final current = (await PackageInfo.fromPlatform()).version;
    if (!_newer(tag, current)) return null;
    return UpdateInfo(tag, apk['browser_download_url'], (j['body'] as String?) ?? '');
  }

  bool _newer(String a, String b) {
    List<int> p(String v) =>
        v.split('+').first.split('.').map((x) => int.tryParse(x) ?? 0).toList();
    final x = p(a), y = p(b);
    for (var i = 0; i < 3; i++) {
      final xi = i < x.length ? x[i] : 0, yi = i < y.length ? y[i] : 0;
      if (xi != yi) return xi > yi;
    }
    return false;
  }

  Stream<OtaEvent> install(String url) =>
      OtaUpdate().execute(url, destinationFilename: 'luna.apk');
}
