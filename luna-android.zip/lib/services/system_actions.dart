import 'package:flutter/services.dart';

class ActionResult {
  ActionResult(this.label, this.message);
  final String label; // shown in the UI
  final String message; // sent back to the model
}

/// Bridge to the Kotlin side (MainActivity). Every tool Gemini can call
/// maps to a method of the same name on the "luna/system" channel.
class SystemActions {
  static const _ch = MethodChannel('luna/system');

  Future<ActionResult> run(String name, Map<String, dynamic> args) async {
    try {
      final msg = await _ch.invokeMethod<String>(name, args) ?? 'Done';
      return ActionResult(msg, msg);
    } on MissingPluginException {
      return ActionResult('Not supported: $name', 'This action is not supported.');
    } on PlatformException catch (e) {
      final m = e.message ?? 'Action failed';
      return ActionResult(m, 'Failed: $m');
    }
  }

  Future<bool> consumeAssistLaunch() async {
    try {
      return await _ch.invokeMethod<bool>('consumeAssistLaunch') ?? false;
    } catch (_) {
      return false;
    }
  }

  Future<void> openAssistantSettings() async {
    try {
      await _ch.invokeMethod('openAssistantSettings');
    } catch (_) {}
  }
}
