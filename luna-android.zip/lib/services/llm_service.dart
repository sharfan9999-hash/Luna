import 'dart:convert';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;
import '../skills/registry.dart';

/// Gemini with function calling. Free-tier key from aistudio.google.com.
/// If Google renames the model, change [model] only.
class LlmService {
  static const model = 'gemini-2.5-flash';
  static const _store = FlutterSecureStorage();
  final List<Map<String, dynamic>> _history = [];

  Future<String?> get apiKey => _store.read(key: 'gemini_key');
  Future<void> saveKey(String k) => _store.write(key: 'gemini_key', value: k.trim());
  Future<String?> get repo => _store.read(key: 'github_repo');
  Future<void> saveRepo(String r) => _store.write(key: 'github_repo', value: r.trim());

  static const _basePrompt =
      'You are Luna, a fast, warm voice assistant on an Android phone. '
      'Replies are spoken aloud: keep them to one or two short sentences, no markdown, no lists. '
      'Use the provided tools to control the phone when asked, then confirm briefly. '
      'If a tool reports it failed or needs permission, say so plainly.';

  Future<String> ask(String text, SkillRegistry skills) async {
    final key = await apiKey;
    if (key == null || key.isEmpty) {
      throw Exception('Add your Gemini API key in settings.');
    }
    _history.add({'role': 'user', 'parts': [{'text': text}]});
    final prompt = '$_basePrompt ${skills.config.extraPrompt}'.trim();

    for (var i = 0; i < 5; i++) {
      final res = await http
          .post(
            Uri.parse(
                'https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent'),
            headers: {'Content-Type': 'application/json', 'x-goog-api-key': key},
            body: jsonEncode({
              'systemInstruction': {'parts': [{'text': prompt}]},
              'contents': _history,
              'tools': [{'functionDeclarations': skills.declarations}],
            }),
          )
          .timeout(const Duration(seconds: 25));

      if (res.statusCode != 200) {
        throw Exception(res.statusCode == 429
            ? 'Free-tier limit reached. Try again in a minute.'
            : 'Gemini error ${res.statusCode}. Check your API key.');
      }
      final content = jsonDecode(res.body)['candidates']?[0]?['content'];
      if (content == null) throw Exception('No response from Gemini.');
      final parts = (content['parts'] as List?) ?? [];
      _history.add({'role': 'model', 'parts': parts});

      final calls = parts.where((p) => p['functionCall'] != null).toList();
      if (calls.isEmpty) {
        final out = parts.map((p) => p['text'] ?? '').join(' ').trim();
        _trim();
        return out.isEmpty ? 'Done.' : out;
      }

      final responses = <Map<String, dynamic>>[];
      for (final c in calls) {
        final fc = c['functionCall'];
        final args = Map<String, dynamic>.from(fc['args'] ?? {});
        final result = await skills.run(fc['name'], args);
        responses.add({
          'functionResponse': {
            'name': fc['name'],
            'response': {'result': result}
          }
        });
      }
      _history.add({'role': 'user', 'parts': responses});
    }
    return 'That took too many steps.';
  }

  void _trim() {
    if (_history.length <= 16) return;
    _history.removeRange(0, _history.length - 12);
    while (_history.isNotEmpty &&
        !(_history.first['role'] == 'user' &&
            (_history.first['parts'] as List).first['text'] != null)) {
      _history.removeAt(0);
    }
  }
}
