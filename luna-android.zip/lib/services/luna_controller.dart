import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;

import '../ui/orb.dart';
import '../skills/registry.dart';
import 'llm_service.dart';
import 'updater.dart';
import 'system_actions.dart';

class LunaController extends ChangeNotifier {
  final _stt = stt.SpeechToText();
  final _tts = FlutterTts();
  final llm = LlmService();
  final actions = SystemActions();
  late final skills = SkillRegistry(actions);
  final updater = Updater();
  UpdateInfo? update;

  LunaState state = LunaState.idle;
  double level = 0;
  String heard = '';
  String reply = '';
  final List<String> actionLog = [];
  bool _ready = false;
  bool _busy = false;

  Future<void> init() async {
    skills.onAction = (a) {
      actionLog.add(a);
      notifyListeners();
    };
    await skills.load(await llm.repo);
    _checkUpdate();
    _ready = await _stt.initialize(
      onStatus: (s) {
        if (s == 'done' && state == LunaState.listening && heard.trim().isEmpty) {
          _set(LunaState.idle);
        }
      },
      onError: (e) => _fail('I could not hear that. (${e.errorMsg})'),
    );
    await _tts.setSpeechRate(skills.config.speechRate ?? 0.5);
    await _tts.setPitch(skills.config.pitch ?? 1.05);
    _tts.setCompletionHandler(() => _set(LunaState.idle));
    _tts.setErrorHandler((_) => _set(LunaState.idle));
  }

  Future<void> _checkUpdate() async {
    final repo = await llm.repo;
    if (repo == null || repo.isEmpty) return;
    try {
      update = await updater.check(repo);
      notifyListeners();
    } catch (_) {}
  }

  Future<String> checkUpdateNow() async {
    final repo = await llm.repo;
    if (repo == null || repo.isEmpty) return 'Add your GitHub repo (owner/name) first.';
    try {
      update = await updater.check(repo);
      notifyListeners();
      return update == null ? 'Luna is up to date.' : 'Update ${update!.version} is ready.';
    } catch (e) {
      return e.toString().replaceFirst('Exception: ', '');
    }
  }

  void _set(LunaState s) {
    state = s;
    if (s != LunaState.listening) level = 0;
    notifyListeners();
  }

  void _fail(String msg) {
    reply = msg;
    _set(LunaState.error);
    Future.delayed(const Duration(seconds: 3), () {
      if (state == LunaState.error) _set(LunaState.idle);
    });
  }

  Future<void> onOrbTap() async {
    if (state == LunaState.listening) {
      await _stt.stop();
    } else if (state == LunaState.speaking) {
      await _tts.stop();
      _set(LunaState.idle);
    } else if (state == LunaState.idle || state == LunaState.error) {
      await listen();
    }
  }

  Future<void> listen() async {
    if (_busy) return;
    if (!_ready) {
      _fail('Luna needs microphone permission to hear you.');
      return;
    }
    await _tts.stop();
    heard = '';
    reply = '';
    actionLog.clear();
    _set(LunaState.listening);
    await _stt.listen(
      onResult: (r) {
        heard = r.recognizedWords;
        notifyListeners();
        if (r.finalResult && heard.trim().isNotEmpty) _handle(heard);
      },
      onSoundLevelChange: (l) {
        level = ((l + 2) / 12).clamp(0.0, 1.0);
        notifyListeners();
      },
      listenFor: const Duration(seconds: 30),
      pauseFor: const Duration(seconds: 3),
      listenOptions: stt.SpeechListenOptions(
          partialResults: true, cancelOnError: true),
    );
  }

  Future<void> _handle(String text) async {
    if (_busy) return;
    _busy = true;
    _set(LunaState.thinking);
    try {
      final out = await llm.ask(text, skills);
      reply = out;
      _set(LunaState.speaking);
      await _tts.speak(out);
    } catch (e) {
      _fail(e.toString().replaceFirst('Exception: ', ''));
    } finally {
      _busy = false;
    }
  }

  @override
  void dispose() {
    _stt.cancel();
    _tts.stop();
    super.dispose();
  }
}
