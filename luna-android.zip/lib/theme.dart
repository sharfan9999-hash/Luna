import 'package:flutter/material.dart';

class LunaColors {
  static const voidBlack = Color(0xFF07030F);
  static const deep = Color(0xFF140A2B);
  static const ultraviolet = Color(0xFF7B2CFF);
  static const magenta = Color(0xFFFF2BD6);
  static const rose = Color(0xFFFF6FB5);
  static const moon = Color(0xFFF6EAFF);
  static const alert = Color(0xFFFF3B6B);
}
