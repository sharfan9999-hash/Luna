import 'package:flutter/material.dart';
import 'package:ota_update/ota_update.dart';
import '../services/luna_controller.dart';
import '../theme.dart';
import 'orb.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with WidgetsBindingObserver {
  final c = LunaController();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    c.addListener(() => setState(() {}));
    c.init().then((_) => _checkAssist());
  }

  // Opened by long-press power / home gesture: start listening right away.
  Future<void> _checkAssist() async {
    if (await c.actions.consumeAssistLaunch()) c.listen();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.resumed) _checkAssist();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    c.dispose();
    super.dispose();
  }

  String _updating = '';

  void _install() {
    c.updater.install(c.update!.apkUrl).listen((e) {
      setState(() {
        switch (e.status) {
          case OtaStatus.DOWNLOADING:
            _updating = 'Downloading ${e.value}%';
            break;
          case OtaStatus.INSTALLING:
            _updating = 'Installing...';
            break;
          case OtaStatus.PERMISSION_NOT_GRANTED_ERROR:
            _updating = 'Allow installs from Luna, then tap again';
            break;
          default:
            if (e.status.toString().contains('ERROR')) _updating = 'Update failed, tap to retry';
        }
      });
    });
  }

  String get _hint {
    switch (c.state) {
      case LunaState.idle:
        return 'Tap the orb to talk';
      case LunaState.listening:
        return 'Listening';
      case LunaState.thinking:
        return 'Thinking';
      case LunaState.speaking:
        return 'Tap to stop';
      case LunaState.error:
        return 'Something went wrong';
    }
  }

  Future<void> _settings() async {
    final ctl = TextEditingController(text: await c.llm.apiKey ?? '');
    final repoCtl = TextEditingController(text: await c.llm.repo ?? '');
    String status = '';
    if (!mounted) return;
    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: LunaColors.deep,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
      builder: (ctx) => StatefulBuilder(builder: (ctx, setSheet) => Padding(
        padding: EdgeInsets.fromLTRB(
            24, 24, 24, MediaQuery.of(ctx).viewInsets.bottom + 24),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Gemini API key',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
          const SizedBox(height: 8),
          const Text('Free key from aistudio.google.com. It stays on this phone.',
              style: TextStyle(color: Colors.white60)),
          const SizedBox(height: 16),
          TextField(
            controller: ctl,
            obscureText: true,
            decoration: const InputDecoration(border: OutlineInputBorder()),
          ),
          const SizedBox(height: 20),
          const Text('Update source',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
          const SizedBox(height: 8),
          const Text('Your public GitHub repo, like yourname/luna. Updates and config come from here.',
              style: TextStyle(color: Colors.white60)),
          const SizedBox(height: 12),
          TextField(
            controller: repoCtl,
            decoration: const InputDecoration(
                border: OutlineInputBorder(), hintText: 'yourname/luna'),
          ),
          const SizedBox(height: 16),
          Row(children: [
            Expanded(
              child: FilledButton(
                style: FilledButton.styleFrom(backgroundColor: LunaColors.magenta),
                onPressed: () async {
                  await c.llm.saveKey(ctl.text);
                  await c.llm.saveRepo(repoCtl.text);
                  await c.skills.load(repoCtl.text.trim());
                  if (ctx.mounted) Navigator.pop(ctx);
                },
                child: const Text('Save'),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: OutlinedButton(
                onPressed: () async {
                  await c.llm.saveRepo(repoCtl.text);
                  final m = await c.checkUpdateNow();
                  setSheet(() => status = m);
                },
                child: const Text('Check for updates'),
              ),
            ),
          ]),
          const SizedBox(height: 8),
          OutlinedButton(
            onPressed: c.actions.openAssistantSettings,
            child: const Text('Set as default assistant'),
          ),
          if (status.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 12),
              child: Text(status, style: const TextStyle(color: LunaColors.rose)),
            ),
        ]),
      )),
    );
  }

  @override
  Widget build(BuildContext context) {
    final showReply = c.reply.isNotEmpty;
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: RadialGradient(
            center: Alignment(0, 0.15),
            radius: 1.1,
            colors: [Color(0xFF2A0B4D), LunaColors.voidBlack],
          ),
        ),
        child: SafeArea(
          child: Column(children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 8, 8, 0),
              child: Row(children: [
                const Text('Luna',
                    style: TextStyle(
                        fontSize: 22, fontWeight: FontWeight.w300, letterSpacing: 4)),
                const Spacer(),
                IconButton(
                  tooltip: 'Settings',
                  onPressed: _settings,
                  icon: const Icon(Icons.tune_rounded, color: LunaColors.rose),
                ),
              ]),
            ),
            Expanded(
              child: GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: c.onOrbTap,
                child: Center(child: LunaOrb(state: c.state, level: c.level)),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 32),
              child: AnimatedSwitcher(
                duration: const Duration(milliseconds: 250),
                child: Text(
                  showReply ? c.reply : c.heard,
                  key: ValueKey(showReply ? c.reply : c.heard),
                  textAlign: TextAlign.center,
                  maxLines: 5,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: showReply ? 20 : 17,
                    height: 1.4,
                    fontWeight: FontWeight.w300,
                    color: showReply ? LunaColors.moon : Colors.white54,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 16),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              alignment: WrapAlignment.center,
              children: [
                for (final a in c.actionLog)
                  Chip(
                    label: Text(a, style: const TextStyle(fontSize: 12)),
                    backgroundColor: LunaColors.ultraviolet.withOpacity(0.25),
                    side: BorderSide(color: LunaColors.magenta.withOpacity(0.5)),
                  ),
              ],
            ),
            if (c.update != null)
              Padding(
                padding: const EdgeInsets.only(top: 16),
                child: FilledButton.icon(
                  style: FilledButton.styleFrom(backgroundColor: LunaColors.ultraviolet),
                  onPressed: _install,
                  icon: const Icon(Icons.system_update_rounded),
                  label: Text(_updating.isEmpty
                      ? 'Update to ${c.update!.version}'
                      : _updating),
                ),
              ),
            const SizedBox(height: 20),
            Text(_hint, style: const TextStyle(color: Colors.white38)),
            const SizedBox(height: 28),
          ]),
        ),
      ),
    );
  }
}
