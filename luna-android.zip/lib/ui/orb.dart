import 'dart:math';
import 'package:flutter/material.dart';
import '../theme.dart';

enum LunaState { idle, listening, thinking, speaking, error }

/// Luna's orb. [level] is the live mic level (0..1) while listening.
class LunaOrb extends StatefulWidget {
  const LunaOrb({super.key, required this.state, this.level = 0});
  final LunaState state;
  final double level;

  @override
  State<LunaOrb> createState() => _LunaOrbState();
}

class _LunaOrbState extends State<LunaOrb> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(seconds: 60))
        ..repeat();
  double _amp = 0.05;

  double _target(double t) {
    switch (widget.state) {
      case LunaState.idle:
        return 0.06 + 0.02 * sin(t * 1.2);
      case LunaState.listening:
        return 0.14 + widget.level * 0.55;
      case LunaState.thinking:
        return 0.22 + 0.05 * sin(t * 4);
      case LunaState.speaking:
        return 0.30 + 0.12 * sin(t * 7) * sin(t * 2.3).abs();
      case LunaState.error:
        return 0.12 + 0.08 * sin(t * 14);
    }
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final reduce = MediaQuery.of(context).disableAnimations;
    return AspectRatio(
      aspectRatio: 1,
      child: AnimatedBuilder(
        animation: _c,
        builder: (_, __) {
          final t = _c.value * 60;
          _amp += ((reduce ? 0.05 : _target(t)) - _amp) * 0.1;
          return CustomPaint(
            painter: _OrbPainter(reduce ? 0 : t, widget.state, _amp),
          );
        },
      ),
    );
  }
}

class _OrbPainter extends CustomPainter {
  _OrbPainter(this.t, this.state, this.amp);
  final double t;
  final LunaState state;
  final double amp;

  (Color, Color) get _pair {
    switch (state) {
      case LunaState.idle:
        return (LunaColors.ultraviolet, LunaColors.magenta);
      case LunaState.listening:
        return (LunaColors.magenta, LunaColors.rose);
      case LunaState.thinking:
        return (LunaColors.ultraviolet, LunaColors.magenta);
      case LunaState.speaking:
        return (LunaColors.magenta, LunaColors.rose);
      case LunaState.error:
        return (LunaColors.ultraviolet, LunaColors.alert);
    }
  }

  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final r = size.shortestSide * 0.26;
    final (a, b) = _pair;

    // Halo
    final haloR = r * (2.2 + amp * 0.9);
    canvas.drawCircle(
      c,
      haloR,
      Paint()
        ..shader = RadialGradient(
          colors: [b.withOpacity(0.40), a.withOpacity(0.16), Colors.transparent],
          stops: const [0, 0.5, 1],
        ).createShader(Rect.fromCircle(center: c, radius: haloR)),
    );

    // Orbit rings
    final spin = state == LunaState.thinking ? 2.4 : 0.5;
    for (var i = 0; i < 3; i++) {
      final rr = r * (1.38 + i * 0.22);
      final dir = i.isEven ? 1 : -1;
      canvas.drawCircle(
        c,
        rr,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.4
          ..shader = SweepGradient(
            colors: [Colors.transparent, a, b, Colors.transparent],
            stops: const [0, 0.35, 0.6, 1],
            transform: GradientRotation(t * spin * dir + i),
          ).createShader(Rect.fromCircle(center: c, radius: rr))
          ..color = Colors.white.withOpacity(0.5 - i * 0.12),
      );
    }

    // Particles while thinking or speaking
    if (state == LunaState.thinking || state == LunaState.speaking) {
      final dot = Paint()..color = LunaColors.moon.withOpacity(0.85);
      final glow = Paint()
        ..color = b.withOpacity(0.6)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 5);
      final n = state == LunaState.thinking ? 16 : 8;
      for (var k = 0; k < n; k++) {
        final ang = t * (1.1 + k * 0.06) + k * 0.9;
        final rad = r * (1.55 + 0.28 * sin(k + t * 1.5));
        final p = c + Offset(cos(ang), sin(ang)) * rad;
        canvas.drawCircle(p, 4, glow);
        canvas.drawCircle(p, 1.6, dot);
      }
    }

    // Liquid core
    final path = Path();
    const steps = 160;
    for (var i = 0; i <= steps; i++) {
      final ang = i / steps * 2 * pi;
      final n = sin(ang * 3 + t * 1.4) * 0.5 +
          sin(ang * 5 - t * 2.1) * 0.3 +
          sin(ang * 2 + t * 0.8) * 0.2;
      final rad = r * (1 + 0.02 * sin(t * 2) + amp * 0.45 * n);
      final p = c + Offset(cos(ang), sin(ang)) * rad;
      i == 0 ? path.moveTo(p.dx, p.dy) : path.lineTo(p.dx, p.dy);
    }
    path.close();

    canvas.drawPath(
      path,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 3
        ..color = b.withOpacity(0.9)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8),
    );
    canvas.drawPath(
      path,
      Paint()
        ..shader = RadialGradient(
          center: const Alignment(-0.3, -0.38),
          radius: 1.05,
          colors: [
            LunaColors.moon.withOpacity(0.95),
            b,
            a,
            LunaColors.deep,
          ],
          stops: const [0, 0.26, 0.68, 1],
        ).createShader(Rect.fromCircle(center: c, radius: r * 1.3)),
    );

    // Specular highlight
    canvas.drawOval(
      Rect.fromCenter(
          center: c + Offset(-r * 0.32, -r * 0.42),
          width: r * 0.5,
          height: r * 0.26),
      Paint()
        ..color = Colors.white.withOpacity(0.35)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6),
    );
  }

  @override
  bool shouldRepaint(covariant _OrbPainter old) => true;
}
