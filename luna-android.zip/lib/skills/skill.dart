/// One thing Luna can do. Add a feature = add a Skill.
class Skill {
  Skill({
    required this.name,
    required this.description,
    required this.run,
    this.params = const {},
    this.required = const [],
  });

  final String name;
  final String description;
  final Map<String, dynamic> params; // Gemini schema, e.g. {'q': {'type': 'STRING'}}
  final List<String> required;
  final Future<String> Function(Map<String, dynamic> args) run;

  Map<String, dynamic> toDeclaration() => {
        'name': name,
        'description': description,
        if (params.isNotEmpty)
          'parameters': {'type': 'OBJECT', 'properties': params, 'required': required},
      };
}
