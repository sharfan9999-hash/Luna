import '../services/system_actions.dart';
import 'skill.dart';

/// Phone-control skills. Each one calls a method of the same name in
/// android/.../MainActivity.kt. To add a new native skill:
///   1. add an entry here   2. add a matching `"name" -> ...` case in MainActivity.kt
List<Skill> builtinSkills(SystemActions sys, void Function(String) onAction) {
  Skill native(String name, String desc,
      [Map<String, dynamic> params = const {}, List<String> req = const []]) {
    return Skill(
      name: name,
      description: desc,
      params: params,
      required: req,
      run: (args) async {
        final r = await sys.run(name, args);
        onAction(r.label);
        return r.message;
      },
    );
  }

  const s = {'type': 'STRING'};
  const i = {'type': 'INTEGER'};

  return [
    native('flashlight', 'Turn the flashlight on or off.',
        {'on': {'type': 'BOOLEAN'}}, ['on']),
    native('set_volume', 'Set media volume 0-100.', {'percent': i}, ['percent']),
    native('set_brightness', 'Set screen brightness 0-100.', {'percent': i}, ['percent']),
    native('open_app', 'Open an installed app by name.', {'name': s}, ['name']),
    native('set_alarm', 'Set an alarm at a 24-hour time.',
        {'hour': i, 'minute': i, 'label': s}, ['hour', 'minute']),
    native('set_timer', 'Start a countdown timer.', {'seconds': i, 'label': s}, ['seconds']),
    native('dial_number', 'Open the dialer with a number. The user taps call.',
        {'number': s}, ['number']),
    native('compose_sms', 'Draft a text message. The user taps send.',
        {'number': s, 'message': s}, ['number', 'message']),
    native('open_settings_panel', 'Open a settings screen.', {
      'panel': {
        'type': 'STRING',
        'enum': ['wifi', 'bluetooth', 'internet', 'display', 'sound', 'hotspot']
      }
    }, ['panel']),
    native('media_control', 'Control media playback.', {
      'action': {
        'type': 'STRING',
        'enum': ['play_pause', 'next', 'previous']
      }
    }, ['action']),
    native('web_search', 'Search the web in the browser.', {'query': s}, ['query']),
    native('get_battery', 'Get the battery percentage.'),
  ];
}
