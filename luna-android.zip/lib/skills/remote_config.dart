import 'dart:convert';
import 'package:http/http.dart' as http;
import 'skill.dart';
import '../services/system_actions.dart';

/// Change Luna WITHOUT rebuilding: edit `luna_config.json` in your GitHub repo
/// (main branch). Luna reads it on every launch. Example file: luna_config.json.
class RemoteConfig {
  String extraPrompt = '';
  double? speechRate;
  double? pitch;
  List<Skill> linkSkills = [];

  static Future<RemoteConfig> load(String? repo, SystemActions sys,
      void Function(String) onAction) async {
    final cfg = RemoteConfig();
    if (repo == null || repo.isEmpty) return cfg;
    try {
      final res = await http
          .get(Uri.parse(
              'https://raw.githubusercontent.com/$repo/main/luna_config.json'))
          .timeout(const Duration(seconds: 6));
      if (res.statusCode != 200) return cfg;
      final j = jsonDecode(res.body) as Map<String, dynamic>;
      cfg.extraPrompt = (j['extraPrompt'] as String?) ?? '';
      cfg.speechRate = (j['speechRate'] as num?)?.toDouble();
      cfg.pitch = (j['pitch'] as num?)?.toDouble();

      // "linkSkills": open a URL built from what you said. No code needed.
      for (final l in (j['linkSkills'] as List? ?? [])) {
        final name = l['name'] as String;
        final template = l['url'] as String; // e.g. https://youtube.com/results?search_query={q}
        cfg.linkSkills.add(Skill(
          name: name,
          description: l['description'] as String,
          params: {'q': {'type': 'STRING'}},
          required: const ['q'],
          run: (args) async {
            final url = template.replaceAll('{q}', Uri.encodeComponent('${args['q'] ?? ''}'));
            final r = await sys.run('open_url', {'url': url});
            onAction(r.label);
            return r.message;
          },
        ));
      }
    } catch (_) {
      // Offline or bad JSON: Luna just runs with its built-in setup.
    }
    return cfg;
  }
}
