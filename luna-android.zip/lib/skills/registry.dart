import '../services/system_actions.dart';
import 'builtin_skills.dart';
import 'remote_config.dart';
import 'skill.dart';

/// Everything Luna can do right now = built-in skills + remote link skills.
class SkillRegistry {
  SkillRegistry(this.sys);
  final SystemActions sys;
  final Map<String, Skill> _skills = {};
  RemoteConfig config = RemoteConfig();
  void Function(String) onAction = (_) {};

  Future<void> load(String? repo) async {
    _skills.clear();
    for (final s in builtinSkills(sys, (m) => onAction(m))) {
      _skills[s.name] = s;
    }
    config = await RemoteConfig.load(repo, sys, (m) => onAction(m));
    for (final s in config.linkSkills) {
      _skills[s.name] = s;
    }
  }

  List<Map<String, dynamic>> get declarations =>
      _skills.values.map((s) => s.toDeclaration()).toList();

  Future<String> run(String name, Map<String, dynamic> args) async {
    final s = _skills[name];
    if (s == null) return 'Unknown action: $name';
    return s.run(args);
  }
}
