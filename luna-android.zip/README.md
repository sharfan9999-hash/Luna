# Luna (Android)

Neon violet-pink voice assistant. Flutter UI, Kotlin phone control, Gemini brain.

## Why the first zip would not install
That zip was source code, not an app. Phones only install an .apk file. This version builds the APK for you in the cloud (GitHub Actions), no Flutter on your computer needed.

## Get the app (needs a PC and a free GitHub account, about 10 minutes)
1. github.com > New repository > name it `luna` > set it to **Public** > create.
2. Unzip this project. On the repo page: Add file > Upload files > drag in everything inside the `luna` folder
   (including the hidden `.github` folder: if your file manager hides it, turn on "show hidden files") > Commit.
3. Open the **Actions** tab > "Build Luna APK" > Run workflow. Wait about 8 minutes.
4. Open the finished run > Artifacts > `luna-apk` > download, unzip, send `luna.apk` to your phone.
5. On the phone open the APK. Android will ask to allow "install unknown apps" for your browser or Files app: allow it, then install.
6. Open Luna > tune icon > paste your free Gemini key (aistudio.google.com) and your repo name (`yourname/luna`) > Save.

## Publish an update (Luna installs it for you)
1. Edit any file in the repo (or upload new ones).
2. Releases > Draft a new release > tag `v0.2.0` (always higher than the last) > Publish.
3. The build runs by itself and attaches `luna.apk` to that release.
4. On the phone Luna shows an "Update to 0.2.0" button on launch (or tune icon > Check for updates). Your key and settings stay.
All builds use the same signing key (`ci/debug.keystore`), so updates install over the old version. It is a throwaway key for personal use, not for the Play Store.

## Change Luna without any new APK
Edit `luna_config.json` in the repo and Luna reads it on every launch:
- `extraPrompt`: personality and rules added to Luna's instructions
- `speechRate`, `pitch`: voice feel
- `linkSkills`: new abilities that open a link built from what you say (YouTube search, Maps, any site with `{q}` in the URL)

## Add a real feature (needs a new release)
- Where things live: `lib/skills/builtin_skills.dart` (what Luna can do), `android_overlay/.../MainActivity.kt` (the phone code behind each skill),
  `lib/ui/orb.dart` (the look), `lib/theme.dart` (colors), `lib/services/llm_service.dart` (Gemini).
- A new phone skill = one entry in `builtin_skills.dart` + one matching case in `MainActivity.kt`.
- Pure-Dart skills (calls to other APIs) only need the Dart entry; its `run` function can do anything.

## Status
Never built or run on a device by me: the first cloud build may fail on a small error. If it does, open the failed run in Actions, copy the red error text to me and I will fix it.

Working in code: orb with 5 states, voice in and out, Gemini tool calling, flashlight, volume, brightness (one-time permission),
open app, alarm, timer, dial, SMS draft, settings screens, media keys, web search, battery, default-assistant registration,
in-app updates, remote config.
Not done: "Hey Luna" wake word, screenshots, action history, direct Wi-Fi/hotspot toggling (blocked by Android 10+). iPhone is not supported.
